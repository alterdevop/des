#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char buf[32];

void banner(){
    printf("   ▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓\n   ▓╫─▄▀────────────▄▀───────────▄▀─╫▓\n   ▓╫─▀▄───────────▐█────────────▀▄─╫▓\n   ▓╫─▄▌▄───────────▀▄───────────▄▌▄╫▓\n   ▓▄▀░▓░▀▄──────────▌─────────▄▀░▓░▀▓\n   ▓░░░░░░░▌──────▄▄▀▀▄▄──────▐▓░░░░░▓\n   ▓▓░░░░░▓▀────▄▀░░▓▓░░▀▄────▀▄░░░░░▓\n   ▓╫▓█▓█▓─────▐▓░░░░░░░░▓▌─────▓█▓█▓▓\n   ▓╫▐░░░▌─────██▀▀▀▀▀▀▀▀██─────▐░░░╫▓\n   ▓╫▐░█░▌───▄▄████████████▄▄───▐░█░╫▓\n   ▓╫▐░░░▌───▐▓▓▓▌▐▒▓▓▒▌▐▓▓▓▌───▐░░░╫▓\n   ▓╫▐░█░▌───▐▓▓▓▌▐▓▒▒▓▌▐▓▓▓▌───▐░█░╫▓\n   ▓╫▐░░░▌▄▄▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█▄▐░░░╫▓\n   ▓╫▐░█░███▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███░█░╫▓\n   ▓╫▐░░░▌░█▒▒▒▒▒▒▒▒▒▓▒▒▒▒▒▒▒▓▒▒▐░█░╫▓\n");
}
void FlagReader(int inp){
    printf("بارك الله فيك \n");

    int fd = inp - 0x1337;
    int len = 0;
    len = read(fd, buf, 32);
    puts(buf);
    if(!strcmp("LETMEWIN\n", buf)){
        printf("إن شاء الله في ميزان حسناتك\n");
        system("/bin/cat flag.txt");
        exit(0);
    }
    printf("[-] Linux file IO, File Descryptor and Ramadhan\n");
}
void setup() {
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stdin, NULL, _IONBF, 0);
}

void reader()
{
    char buffer[16];

    printf("\n             -> الله أكبر <- \n\n =*= Welcome To Another Learning Experience =*=\n");
    printf("         => Take The Risk Or Take It <=\n");
    printf("         => There Is No Other Option <=\n");
    printf("   => Tell Me Something I have Never Heard <=\n\n >> ");
    scanf("%s", buffer);
    printf("[-] Yes, Well, %s I Know That\n", buffer);    
}

int main() {
    setup();
    banner();
    reader();
    return 0;
}


