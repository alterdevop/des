#!/bin/sh
cd /home/ctf/ && ./main

